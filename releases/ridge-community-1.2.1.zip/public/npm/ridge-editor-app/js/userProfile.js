export default {
  name: 'UserProfile',
  externals: {
    axios: 'axios/dist/axios.min.js'
  },
  properties: [{
    label: '打开',
    name: 'open',
    type: 'string',
    value: '0'
  }],
  events: [{
    name: 'close',
    label: '关闭'
  }],
  state: {
    openDialog: false, // 打开对话框
    id: '',
    avatar: '',
    type: '',
    typeLabel: '',
    showPromote: false,
    showPayment: false,
    confirmed: '',
    payments: [],
    userApps: [],
    userAppTree: [],
    quotaPercent: 2,
    quotaText: '',
    npmToken: '',
    showAppList: false,
    currentTreeApp: '',
    currentAppName: '',
    currentAppVersion: '',
    currentAppDesc: '',
    currentAppUpload: '',
    currentAppPublishStatus: ''
  },

  computed: {

  },

  async setup () {
    // this.fetchUserStoreData()
  },

  destory () {
  },

  watch: {
    openDialog () {
      if (this.openDialog === false) {
        this.emit('close')
      }
    },
    open () {
      if (this.properties.open === '1') {
        this.openDialog = true
        this.fetchUserStoreData()
      }
    }
  },

  actions: {
    getServerUrl () {
      return this.composite.appPackageObject.ridgeServerUrl || 'http://localhost:7080'
    },
    async fetchUserStoreData () {
      const responseData = (await this.axios.get(this.getServerUrl() + '/api/app/storage/status', {
        withCredentials: true
      })).data

      if (!responseData.data.user) {
        return
      }
      const typeMap = {
        free: '免费账号',
        pay: '付费账号',
        advanced: '高级用户'
      }
      const user = responseData.data.user
      this.id = user.id
      this.type = user.type

      const usedLength = responseData.data.storeList.length
      this.quotaText = usedLength + '/' + responseData.data.rule.appCount

      this.quotaPercent = usedLength / responseData.data.rule.appCount * 100
      this.userApps = responseData.data.storeList
      if (this.userApps.length) {
        this.showAppList = true
      }
      this.userAppTree = responseData.data.storeList.map(item => {
        return {
          value: item.name,
          key: item.name,
          label: item.name
        }
      })
      if (this.currentTreeApp === '' && this.userApps.length) {
        this.currentTreeApp = this.userApps[0].name
        this.treeNodeChange()
      }

      this.typeLabel = typeMap[this.type]
      if (this.type === 'free') {
        this.showPromote = true
      }
      if (!user.confirmed) {
        this.showPayment = true
      }
    },

    async removeApp () {
      const responseData = (await this.axios.post(this.getServerUrl() + '/api/app/storage/delete', {
        app: this.currentTreeApp
      })).data
      if (responseData.code === '0') {
        await this.fetchUserStoreData()
      }
    },

    treeNodeChange () {
      const resultDict = {
        success: '已成功发布',
        queue: '发布中',
        'not-allowed': '发布失败：无权限'
      }
      const currentSelectedApp = this.userApps.find(app => app.name === this.currentTreeApp)
      this.currentAppName = currentSelectedApp.name
      this.currentAppVersion = currentSelectedApp.version
      this.currentAppDesc = currentSelectedApp.description
      this.currentAppUpload = currentSelectedApp.updatedAt
      this.currentAppPublishStatus = resultDict[currentSelectedApp.publishResult] || '未知'
    }
  }
}
