
export default {
  name: 'DialogRepoApp',
  state: () => {
    return {
      showDialog: false  // 显示
    }
  },

  computed: {
    hello: (state) => { // 欢迎语
      return 'Hello ' + state.name
    }
  },

  async setup () {
  },

  destory () {
  },

  watch: {
  },

  actions: {
    changeName () {  // 改名
      this.state.name = 'VisionFlow'
    }
  }
}
