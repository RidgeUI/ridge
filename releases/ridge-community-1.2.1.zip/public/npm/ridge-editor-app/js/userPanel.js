export default {
  name: 'UserPanel',
  externals: {
    axios: 'axios/dist/axios.min.js'
  },
  state: {
    userAvatar: '',
    userId: '',
    loginUserModalVisible: false,
    registerUserModalVisible: false,
    userProfileModalVisible: false,
    displayState: ''
  },

  computed: {
  },

  async setup () {
    this.serviceUrl = this.composite.appPackageObject.ridgeServerUrl || ''
    this.checkLoginStatus()
  },

  destory () {
  },

  watch: {
  },

  actions: {
    openUserProfileModal () { // 打开用户配置
      this.state.userProfileModalVisible = true
    },

    closeRegisterModal () {
      this.state.registerUserModalVisible = false
    },
    closeLoginModal () {
      this.state.loginUserModalVisible = false
    },
    toggleLoginModal () {
      this.state.loginUserModalVisible = true
      this.state.registerUserModalVisible = false
    },
    toggleRegisterModal () {
      this.state.loginUserModalVisible = false
      this.state.registerUserModalVisible = true
    },

    confirm (msg, onOk) {
      if (window.SemiUI) {
        const { Modal } = window.SemiUI
        Modal.confirm({
          zIndex: 10001,
          title: '操作确认',
          content: msg,
          onOk
        })
      } else {
        onOk()
      }
    },

    async checkLoginStatus () { // 检查用户登录状态
      this.closeRegisterModal()
      this.closeLoginModal()
      try {
        const response = (await this.axios.get(this.serviceUrl + '/api/user/current', {
          withCredentials: true
        })).data
        if (res.code === '100404') {
          throw new Error('No API') 
        } else if (response.data.user) {
          this.state.userId = response.data.user.id
          this.state.displayState = 'logon'
          globalThis.ridgeUser = response.data.user
        } else {
          this.state.displayState = 'unlogin'
          globalThis.ridgeUser = null
        }
      } catch (e) {
        console.log(e)
        this.state.displayState = 'community'
      }
    },

    async logout () { // 退出登录
      this.confirm('确认退出当前用户登录', async () => {
        const response = (await this.axios.post(this.serviceUrl + '/api/user/logout', {}, {
          withCredentials: true
        })).data
        this.checkLoginStatus()
      })
    },
    openLoginModal () { // 打开登录框
      this.state.loginUserModalVisible = true
    },

    loginConfirmed () { // 登录成功
      this.checkLoginStatus()
    },

    profileClose () { // 配置框关闭
      this.state.userProfileModalVisible = false
    }
  }
}
